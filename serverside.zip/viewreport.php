
<?php
include 'connectreport.php';?>

<!DOCTYPE html>  
<html>  
<head>  
	<title>Hazard Report</title>
<meta name="viewport" content="width=device-width, initial-scale=1">  
	<meta charset="utf-8">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color:lightblue;
}  
	h1 {
	 font-size: 40px;	
	}
	
	h3 {
	 font-size: 40px;	
		color: #005F3D;
	}
	

  
input[type=text]{  
  width: 65%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;
}  
	
input[type=text]:focus {  
  outline: none;  
}  	
 div {  
         padding: 10px 100px;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 65%;  
  opacity: 0.9; 
  align-content: center;
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style>  

<body>
	
<div class="container">
	<br><br><br>
	<h3 style="text-align: center"><strong>Hazard Report</strong></h3>

<div class="container">
	<table class="table">
  <thead>
    <tr>
	  <th scope="col">ID</th>
      <th scope="col">Hazard Type</th>
      <th scope="col">Date</th>
      <th scope="col">Time</th>
      <th scope="col">Latitude</th>
	  <th scope="col">Longitude</th>
	  <th scope="col">Location</th>
	  <th scope="col">Reporter Name</th>
    </tr>
  </thead>
  <tbody>
	  
	  <?php 
	  $sql = "SELECT * FROM hazard";
	  $result = mysqli_query($conn,$sql);
	  if($result){
		 
		  while($row=mysqli_fetch_assoc($result)){
			    $id  = $row['id'];
			    $hazardType  = $row['hazardType'];
				$hazardDate = $row['hazardDate'];
			    $hazardTime = $row['hazardTime'];
				$lat= $row['lat'];
				$lng = $row['lng'];
			    $hazardLocation = $row['hazardLocation'];
			    $hazardReporter = $row['hazardReporter'];
			  echo '<tr>
				  <th scope="row">'.$id.'</th>
				  <td>'.$hazardType.'</td>
				  <td>'.$hazardDate.'</td>
				  <td>'.$hazardTime.'</td>
				  <td>'.$lat.'</td>
				  <td>'.$lng.'</td>
				  <td>'.$hazardLocation.'</td>
				  <td>'.$hazardReporter.'</td>
				  	</tr>';
		  }
	  }
	  
	  ?>
	  
    
  </tbody>
</table>
	
	<br>
	<center>
	<button type="submit" class="registerbtn" name="report"><a href="Report.php" style="color: white">Report</a></button> 
		</center>
	</div>
	
	
	</body>

</html>
		