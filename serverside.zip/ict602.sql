-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2022 at 04:06 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sampledb3`
--

-- --------------------------------------------------------

--
-- Table structure for table `hazard`
--

CREATE TABLE `hazard` (
  `id` int(10) NOT NULL,
  `hazardType` varchar(60) NOT NULL,
  `hazardDate` varchar(15) NOT NULL,
  `hazardReporter` varchar(50) NOT NULL,
  `hazardTime` varchar(15) NOT NULL,
  `hazardLocation` varchar(50) NOT NULL,
  `lat` varchar(50) NOT NULL,
  `lng` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hazard`
--

INSERT INTO `hazard` (`id`, `hazardType`, `hazardDate`, `hazardReporter`, `hazardTime`, `hazardLocation`, `lat`, `lng`) VALUES
(1, 'Electrical Hazards', '17/10/2021', 'Sulaiman Yusoff', '09:12 AM', 'Alor Setar', '6.147', '100.371'),
(2, 'Fire Hazard', '20/07/2021', 'Mohd Mustafa ', '23:40 PM', 'Alor Setar', '6.141', '100.564'),
(3, 'Chemical Exposure', '20/06/2021', 'Ahmad Johari', '17:30 PM', 'Penang', '6.323', '104.290'),
(4, 'Repetitive Motion Injury', '10/01/2022', 'Shuhada Hani', '07:40 AM', 'Sungai Petani', '5.645', '100.564'),
(5, 'Chemical Exposure', '23/06/2021', 'Mohd Yaakob ', '14:40 PM', 'Penang', '5.441624', '100.3447'),
(6, 'Fire Hazard', '14/03/2021', 'Nur Rafidah ', '23:40 PM', 'Gerik', '5.3732', '101.1302');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hazard`
--
ALTER TABLE `hazard`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
