<?php
require_once('hazardprocess.php');
?>

<!DOCTYPE html>  
<html>  
<head>  
	<title>New Hazard Report</title>
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color:#124715;  
}  
	h1 {
	 font-size: 40px;	
	}
.container {  
  padding: 10px;  
  background-color: lightblue;  
}  
  

input[type=text]{  
  width: 65%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;
}  
	
input[type=text]:focus {  
  outline: none;  
}  	
 div {  
         padding: 5px 100px;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 65%;  
  opacity: 0.9; 
  align-content: center;
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style>  
</head>  
<body>  
	<div>
	<?php
	if(isset($_POST['report'])){
		$hazardType  = $_POST['hazardType'];
		$hazardDate = $_POST['hazardDate'];
		$hazardReporter = $_POST['hazardReporter'];
		$hazardTime = $_POST['hazardTime'];
		$lat= $_POST['lat'];
		$lng = $_POST['lng'];
		$hazardLocation = $_POST['hazardLocation'];

		$sql = "INSERT INTO hazard (hazardType, hazardDate, hazardReporter, hazardTime, lat, lng, hazardLocation) 
		VALUES (?,?,?,?,?,?,?)";
		$stmtinsert = $db->prepare($sql);
		$result = $stmtinsert->execute([$hazardType, $hazardDate, $hazardReporter, $hazardTime, $lat, $lng, $hazardLocation]);
		
	}
	?>
</div>
<form align = "center" form action="Report.php" method="post">
  <div class="container">  
  <center>  <h1> Hazard Report</h1> </center>
  <input type="text" name="hazardType" placeholder= "Type of Hazard" size="15" />
  <input type="text" name="lat" placeholder="Latitude" size="15" />       
  <input type="text" name="lng" placeholder="Longtitude" size="15"/><br>
  <input type="text" name="hazardLocation" placeholder="Location Name" size="15"/><br>
  
  <input style="font-size: 1.0rem"  type="date" name="hazardDate" id="Date" />
	  
  <input style="font-size: 1.0rem"  type="time" name="hazardTime" id="time" /><br>  
	  
  <input type="text" placeholder="Reporter Name" name="hazardReporter" >  
  <button type="submit" class="registerbtn" name="report" onClick="alert('Successfully reported')">Report</button> 
  <button type="submit" class="registerbtn"><a href="viewreport.php" style="color: white" >View Report</a></button>
  </div>
</form>  
</body>  
</html>  